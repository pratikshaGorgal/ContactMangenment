import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { ContactService } from '../contact.service';
import { IContact } from 'src/models/IContact';
import { IGroup } from 'src/models/IGroup';

@Component({
  selector: 'app-view-contact',
  templateUrl: './view-contact.component.html',
  styleUrls: ['./view-contact.component.css']
})
export class ViewContactComponent implements OnInit {

  public contactId:string |null=null;
  public loading:boolean=false;
  public contact:IContact={} as IContact;
  public errorMessage:string |null=null;
  public group:IGroup={} as IGroup;
  constructor(private activated:ActivatedRoute, private contactService:ContactService){}
  ngOnInit(): void {

      this.activated.paramMap.subscribe((param:Params)=>{
        this.contactId= param['get']('contactId');
});
if(this.contactId)
{
  this.loading=true;
  this.contactService.getContact(this.contactId).subscribe((data:IContact)=>{
    this.contact=data;
    this.loading=false;
    this.contactService.getGroup(data).subscribe((data:IGroup)=>{
this.group=data;
    });
},(error)=>{
  this.errorMessage=error;
  this.loading=false;
  
});
}

  }
  public isNotEmpty()
  {
    return Object.keys(this.contact).length > 0 && Object.keys(this.group).length >0 ;

  }

}
