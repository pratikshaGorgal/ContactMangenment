import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactMangerComponent } from './contact-manger.component';

describe('ContactMangerComponent', () => {
  let component: ContactMangerComponent;
  let fixture: ComponentFixture<ContactMangerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ContactMangerComponent]
    });
    fixture = TestBed.createComponent(ContactMangerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
