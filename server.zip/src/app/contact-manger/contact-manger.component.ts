import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-manger',
  templateUrl: './contact-manger.component.html',
  styleUrls: ['./contact-manger.component.css']
})
export class ContactMangerComponent {

}
